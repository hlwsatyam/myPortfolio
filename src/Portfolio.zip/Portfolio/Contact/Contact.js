function Contact() {

    return (
        <>Contact</>
    )

}

export default Contact;