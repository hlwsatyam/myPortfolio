import { Link, Outlet } from "react-router-dom";
import './navigate.css'
function Navigation() {

    return (
        <>
            <div className="container-fluid" >
                <div>  <Link to="/"  >Anisha</Link>  </div>
                <div>  <Link to="/"  >Home</Link>  </div>
                <div>  <Link to="About"  >About</Link>  </div>
                <div>  <Link to="Contact"  >Contact</Link>  </div>


            </div>
            <Outlet />
        </>

    )

}

export default Navigation;